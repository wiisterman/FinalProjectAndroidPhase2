package com.kylecolt.finalprojectphase2;

public class RaceGame
{

    private int goalScore;
    private int streakP1;
    private int streakP2;

    public RaceGame()
    {
        streakP1 = 0;
        streakP2 = 0;
    }

    public int getGoalScore() {
        return goalScore;
    }

    public void setGoalScore(int goalScore) {
        this.goalScore = goalScore;
    }

    public int getStreakP1() {
        return streakP1;
    }

    public void setStreakP1(int streakP1) {
        this.streakP1 = streakP1;
    }

    public int getStreakP2() {
        return streakP2;
    }

    public void setStreakP2(int streakP2) {
        this.streakP2 = streakP2;
    }

    public void streakIncrease(String player1OrPlayer2, int streak)
    {
        if(player1OrPlayer2.equals("P1"))
        {
            this.streakP1 +=streak;
        }
        else
        {
            this.streakP2 +=streak;
        }
    }

    public void resetStreak(String player1OrPlayer2, int streak)
    {
        if(player1OrPlayer2.equals("P1"))
        {
            this.streakP1 = 1;
        }
        else
        {
            this.streakP2 = 1;
        }
    }

    public boolean isWon(int numOfQuestionsAsked)
    {
        if(numOfQuestionsAsked == goalScore)
        {
            //stop send true
            return true;
        }
        else return false;
    }






}
