package com.kylecolt.finalprojectphase2;

public class Question
{


    private String question;
    private String cAnswer;



    public Question(String question, String cAnswer) {
        this.question = question;
        this.cAnswer = cAnswer;

    }


    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getcAnswer() {
        return cAnswer;
    }

    public void setcAnswer(String cAnswer) {
        this.cAnswer = cAnswer;
    }




    @Override
    public String toString() {
        return "Question: " +question+ "\nAnswer: " + cAnswer+"\n";
    }


}
