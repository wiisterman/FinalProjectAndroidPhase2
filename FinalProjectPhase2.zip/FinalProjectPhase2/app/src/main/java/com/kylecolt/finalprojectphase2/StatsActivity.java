package com.kylecolt.finalprojectphase2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class StatsActivity extends AppCompatActivity {

    private TextView statsTexts;
    private DatabaseManager udb;
    private ArrayList<User> aList;
    private Menu mMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stats);
        statsTexts = findViewById(R.id.outPutText);
        statsTexts.setMovementMethod(new ScrollingMovementMethod());
        udb = new DatabaseManager(getApplicationContext());
        aList = new ArrayList<>();
        populateEditText();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.helpbarmenu, menu);
        mMenu = menu;
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        // Determine which menu option was chosen
        switch (item.getItemId()) {
            case R.id.action_Help:

                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    public void populateEditText()
    {
      aList=  udb.getAllUsers();

      String allStats = "";

      for (int i = 0; i<aList.size(); i++)
      {
          allStats+=aList.get(i).toString()+"\n";
      }
      statsTexts.setText(allStats);

    }

    public void sortLtoH()
    {
        aList=  udb.getAllUsers();

        String allStats = "";
        Collections.sort(aList, new lowToHigh());
        for (int i = 0; i<aList.size(); i++)
        {
            allStats+=aList.get(i).toString()+"\n";
        }
        statsTexts.setText(allStats);


    }

    public void sortHtoL()
    {
        aList=  udb.getAllUsers();

        String allStats = "";
        Collections.sort(aList, new highToLow());
        for (int i = 0; i<aList.size(); i++)
        {
            allStats+=aList.get(i).toString()+"\n";
        }
        statsTexts.setText(allStats);


    }


    public void sortBtn1(View view)
    {
        sortHtoL();
    }

    public void sortBtn2(View view)
    {
        sortLtoH();
    }
}
