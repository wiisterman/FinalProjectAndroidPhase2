package com.kylecolt.finalprojectphase2;

import java.util.ArrayList;

public class Test
{

    private String testName;
    private ArrayList<Question> qArr;

    public Test(String testName, ArrayList<Question> qArr) {
        this.testName = testName;
        this.qArr = qArr;
    }

    public String getTestName() {
        return testName;
    }

    public void setTestName(String testName) {
        this.testName = testName;
    }

    public ArrayList<Question> getqArr() {
        return qArr;
    }

    public void setqArr(ArrayList<Question> qArr) {
        this.qArr = qArr;
    }

    @Override
    public String toString() {
        return "Test: "+ testName+"\n"+"Questions: \n"+
                qArr.toString()+"\n";
    }

}
