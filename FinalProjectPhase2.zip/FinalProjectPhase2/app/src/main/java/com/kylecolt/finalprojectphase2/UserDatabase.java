package com.kylecolt.finalprojectphase2;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

public class UserDatabase extends SQLiteOpenHelper
{
    private static final String DATABASE_NAME = "userDB";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE = "Users";
    private static final String ID = "ID";
    private static final String USERNAME = "UserName";
    private static final String QUESTIONS_RIGHT = "QRight";
    private static final String QUESTIONS_WRONG = "QWrong";

    private static UserDatabase uDB;

    public UserDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public static UserDatabase getInstance(Context context) {
        if (uDB == null) {
            uDB = new UserDatabase(context);
        }
        return uDB;
    }
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create table " + UserDatabase.TABLE+ "("+ UserDatabase.ID+" integer primary key autoincrement, "+UserDatabase.USERNAME+
                " text, " + UserDatabase.QUESTIONS_RIGHT+ " integer, "+
                UserDatabase.QUESTIONS_WRONG+ " integer)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop table if exists " + TABLE);
        onCreate(sqLiteDatabase);
    }

    public void insert(User u) {

        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserDatabase.USERNAME, u.getUsername());
        values.put(UserDatabase.QUESTIONS_RIGHT,0);
        values.put(UserDatabase.QUESTIONS_WRONG,0);

        db.insert(UserDatabase.TABLE,null,values);

    }


    public ArrayList<User> selectAll( ) {
        String sqlQuery = "select * from " + TABLE;

        SQLiteDatabase db = this.getWritableDatabase( );
        Cursor cursor = db.rawQuery( sqlQuery, null );

        ArrayList<User> userList = new ArrayList<User>( );
        while( cursor.moveToNext( ) ) {
            User u = new User();
            u.setID(cursor.getInt(0));
            u.setUsername(cursor.getString(1));
            u.setQuesRight(cursor.getInt(2));
            u.setQuesWrong(cursor.getInt(3));
            userList.add(u);
        }
        db.close( );
        return userList;
    }

    public User getUser(String username) {
        SQLiteDatabase db = getReadableDatabase();
        User x = new User();
        String sql = "select * from " + UserDatabase.TABLE + " where username = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { username });
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String uName = cursor.getString(1);
                int qr = cursor.getInt(2);
                int qw = cursor.getInt(3);

                x.setUsername(uName);
                x.setQuesRight(qr);
                x.setQuesWrong(qw);

            } while (cursor.moveToNext());
        }
        cursor.close();
        return x;
    }

    public void  updateUser(User u)
    {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserDatabase.USERNAME, u.getUsername());
        values.put(UserDatabase.QUESTIONS_RIGHT,u.getQuesRight());
        values.put(UserDatabase.QUESTIONS_WRONG,u.getQuesWrong());
        db.update(UserDatabase.TABLE, values, "ID= "+u.getID(),null);
    }

}



